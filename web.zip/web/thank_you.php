<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="sticky-header">
        <!-- Your header content here -->
    </header>

    <div class="content">
        <section id="thank_you">
            <?php
            if (isset($_GET['status']) && $_GET['status'] == 'success') {
                echo "<h1>Thank you for your submission!</h1>";
                echo "<p>Your message has been recorded. Our team will contact you shortly.</p>";
            } elseif (isset($_GET['status']) && $_GET['status'] == 'error') {
                echo "<h1>Something went wrong!</h1>";
                echo "<p>There was an error processing your submission. Please try again later.</p>";
            } else {
                echo "<h1>Unexpected Error</h1>";
                echo "<p>Something went wrong. Please try again later.</p>";
            }
            ?>
            <a href="index.html">Go back to the form</a>
        </section>
    </div>
</body>
</html>
